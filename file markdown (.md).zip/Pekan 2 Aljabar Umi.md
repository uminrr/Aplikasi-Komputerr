﻿# PENGGUNAAN SOFTWARE EMT UNTUK ALJABAR
Umi Nurkhasanah (22305141032)


# Operasi Bentuk-Bentuk Aljabar

## Pengertian Aljabar

Aljabar adalah salah satu bagian dari ilmu matematika terkait ilmu
bilangan,geometri dan analisis penyelesaiannya dengan menggunakan atau
mengandung huruf-huruf atau yang biasa kita sebut sebagai variabel.


Pada aljabar, dikenal beberapa istilah sebagai berikut


1. Variabel, yaitu lambang pengganti nilai yang belum diketahui.


2. Koefisien, yaitu angka yang biasanya mengiringi huruf atau
variabel.


3. Konstanta, yaitu angka yang terdapat dalam persamaan dan berdiri
sendiri.


4. Suku


   a. Suku sejenis, yaitu suku-suku yang memiliki variabel yang sama
dan pangkat yang sama pula.


   b. Suku tak sejenis, yaitu yaitu suku-suku yang memiliki variabel
yang berbeda, atau variabel yang sama namun memiliki pangkat yang
berbeda juga tergolong dalam suku ini.


Perhatikan contoh bentuk lajabar berikut


x dan y merupakan suatu variabel


2 merupakan koefisien dari x dan 3 merupakan koefisien dari y


4 merupakan suatu konstanta


2x dan 3y merupakan suku tak sejenis


## Operasi Penjumlahan Aljabar dengan EMT



Penjumlahan merupakan penambahan sekelompok bilangan atau lebih
menjadi suatu bilangan yang disebut jumlah. Dalam konteks aljabar,
syarat penjumlahan adalah suku sukunya harus sejenis. Seperti dengan
perhitungan aritmatika lainnya, operasi penjumlahan disimbolkan dengan
tand "+"


---



SOAL R.3 No 7


Melakukan operasi yang ditunjukkan


\>$& (2\*x+3\*y+z-7)+(4\*x-2\*y-z+8)+(-3\*x+y-2\*z-4)


Penjelasan:


2x, 4x, dan -3x merupakan suku sejenis, sehingga akan akan
dikelompokkan dan dijumlahkan, menghasilkan 3x


3y, -2y, dan y merupakan suku sejenis, sehingga akan dikelompokkan dan
dijumlahkan, menghasilkan 3y


z, -z, dan -2z merupakan suku sejenis, sehingga akan dikelompokkan dan
dijumlahkan, menghasilkan -2z


-7, 8, dan -4 merupakan konstanta, sehingga akan dikelompokkan dan
dijumlahkan, menghasilkan -3


Jadi hasil akhirnya adalah


---



SOAL 2


\>$& (3\*x^2+4\*x^4+9\*x^2+6\*x+x^4)


Penjelasan:




merupakan suku sejenis, sehingga akan dikelompokkan dan dijumlahkan,
menghasilkan




merupakan suku sejenis, sehingga akan dikelompokkan dan dijumlahkan,
menghasilkan


6x memiliki 0 pasangan suku sejenis lainnya sehingga tetap ditulis 6x


Jadi hasil akhirnya adalah


---



SOAL 3


\>$& (3\*x^2+4\*x^4+9\*x^2+6\*x+y^4+7\*x) 


Penjelasan:




memiliki 0 pasangan suku sejenis lainnya sehingga tetap ditulis


4x^4


memiliki 0 pasangan suku sejenis lainnya sehingga tetap ditulis




merupakan suku sejenis, sehingga dikelompokkan dan dijumlahkan,
menghasilkan




merupakan suku sejenis, sehingga dikelompokkan dan dijumlahkan,
menghasilkan


Jadi hasil akhirnya adalah


\>  


---



Contoh soal lainnya:


\>$& (3\*a^2+4\*b^4+9\*c^2+6\*d+e^4+b^2+a^2)


langkah pertama yaitu kelompokkan suku-suku yang sejenis.


lalu jumlahkan suku-suku sejenis yang sudah dikelompokkan tadi dengan
yang lainnya.


---



latihan soal:


\>$& (2\*x^2+12\*x\*y-11)+(6\*x^2-2\*x+4)+(-x^2-y-2) 


---

## Operasi Pengurangan Aljabar dengan EMT

Pengurangan adalah operasi matematika yang digunakan untuk mengurangi
satu bilangan dengan bilangan lainnya. Operator pengurangan pada EMT
juga disimbolkan dengan tanda "-"


---



SOAL R.3 No 9


\>$& (3\*x^2-2\*x-x^3+2)-(5\*x^2-8\*x-x^3+4)


penjelasan:


Jika soal tersebut diuraikan, maka dengan adanya sifat distributif
yang dimiliki oleh aljabar akan diperoleh hasil sebagai berikut


Setelah itu, kelompokkan suku sejenis lalu jumlahkan sesuai dengan
suku-suku sejenisnya, maka akan diperoleh hasil sebagai berikut


---



SOAL R.3 No 10


\>$& (5\*x^2+4\*x\*y-3\*y^2+2)-(9\*x^2-4\*x\*y+2\*y^2-1)


penjelasan:


Jika soal tersebut diuraikan, maka dengan sifat distributif yang
dimiliki oleh aljabar akan diperoleh hasil sebagai berikut


Setelah itu, kelompokkan suku sejenis lalu jumlahkan sesuai dengan
suku-suku sejenisnya, maka akan diperoleh hasil sebagai berikut


---



SOAL R.3 No 11


\>$& (x^4-3\*x^2+4\*x)-(3\*x^3+x^2-5\*x+3)


penjelasan:


Jika soal tersebut diuraikan, maka dengan sifat distributif yang
dimiliki oleh aljabar akan diperoleh hasil sebagai berikut


Setelah itu, kelompokkan suku sejenis lalu jumlahkan sesuai dengan
suku-suku sejenisnya, maka akan diperoleh hasil sebagai berikut


---



Latihan soal


\>$& (2\*x^2-3\*x^2+7\*x)-(5\*x^3+2\*x^2-3\*x+5) 


---

## Operasi Perkalian Bentuk Aljabar Dengan EMT

Perkalian secara sederhana dapat dimaknai sebagai penjumlahan
berulang.


Perkalian merupakan proses aritmetika dasar dimana suatu bilangan
dilipatgandakan sesuai dengan bilangan bilangan pengalinya.


Dalam aljabar, operasi perkalian biasanya identik dengan menguraikan
bentuk aljabarnya.


Misal:




dengan menggunakan sifat distribusi, maka perkalian tersebut akan
menghasilkan




(Dijabarkan)


---



SOAL R.3 No


\>$& expand((x+6)\*(x+3))


Penjelasan:


Dengan adanya sifat distribusi, maka




akan menghasilkan


---



SOAL R.3 No 17


\>$& expand((a-b)\*(2\*a^3-a\*b+3\*b^2))

\>$powerdisp:true;


Penjelasan:


Dengan adanya sifat distributif, maka




akan menghasilkan


---



SOAL R.3 No 43


\>$& expand((2\*x+3\*y+4)\*(2\*x+3\*y-4))

\>$powerdisp:false;


Penjelasan:


Dengan adanya sifat distributif, maka




akan menghasilkan


---



SOAL R.3 No 46


\>$& expand((y-2)\*(y+2)\*(y^2+4))


Penjelasan:


Dengan adnaya sifat distributif, maka




akan menghasilkan


---



Latihan Soal


\>$& expand((a-8)\*(a-1))


Penjelasan:


Dengan adanya sifat distributif, maka




akan menghasilkan


---

## Operasi Perpangkatan Aljabar Dengan EMT

Perpangkatan adalah operasi matematika untuk perkalian berulang suatu
bilangan sebanyak pangkatnya. Pangkat suatu bilangan adalah angka yang
ditulis lebih kecil dan terdapat agak ke atas.


---



SOAL 1


Sederhanakan soal bentuk penrpangkatan berikut


\>$& (expand((x+1)^2))


Penyelesaian:


Bentuk soal tersebut dapat dituliskan sebagai:




Sehingga dengan memanfaatkan adanya sifat distributif akan dihasilkan


---



SOAL 2


\>$& (expand((x+2)^3))


Penyelesaian:


Bentuk soal tersebut dapat dituliskan sebagai berikut


(x+2)(x+2)(x+2)


Sehingga dengan adanya sifat distributif akan menghasilkan


---



SOAL 3


\>$& (expand((x+1)^-2))


Operasi perpangkatan dengan pangkat negatif diselesaikan dengan cara
sebagai berikut


sehingga didapat hasilnya:


---



latihan soal:


\>$& expand((5\*x-9\*y)^3)

\>$powerdisp:true; 


---

## Faktorisasi Aljabar dengan EMT

Di faktorisasi, kita akan menggunakan konsep FPB dan sifat distributif
aljabar.


Untuk lebih gampang memahaminya, coba faktorisasi dengan angka
terlebih dahulu, misal


24+60 = 2(12+30)     angka 12 dan 30 masih bisa disederhanakan lagi


      = 2.2(6+15)    angka 6 dan 15 masih bisa disederhanakan lagi


      = 2.2.3(2+5)   karena 2 dan 5 tidak bisa disedderhanakan lagi,


      = 12(7)


Jadi faktor yang akan kita ambil adalah yang terbesar, yaitu 12 dan 7.


Sekarang, coba dengan variabel




masih bisa disederhanakan lagi




karena sudah tidak bisa disederhanakan lagi,


Karena angka 12 dan 5 tidak bisa difaktorkan, maka faktor terbesarnya
adalah


Sekarang kita akan mencoba memfaktorkan di aplikasi EMT dengan mencoba
soal-soal berikut ini.


---



SOAL R.4 No 23


\>$& factor(t^2+8\*t+15)


Penjelasan:


Akan dibuktikan benar yaitu ketika mengalikan faktor tersebut akan
menghasilkan


\>$& expand((t+3)\*(t+5))


Karena hasil dari perkalian faktor tersebut menghasilkan hasil yang
sama, maka hasil pemfaktoran tersebut sudah benar.


---



SOAL R.4 No 54


\>$& factor(5\*x^2\*y-5\*y\*z^4)


Penjelasan:


Akan dibuktikan bahwa




merupakan faktor dari




yaitu dengan mengalikannya kembali


\>$& expand(-5\*y\*(z^2-x)\*(z^2+x))


Karena hasil dari perkalian faktor tersebut menghasilkan hasil yang
sama, maka hasil pemfaktoran tersebut sudah benar.


---



SOAL R.4 No 65


\>$& factor(4\*p^2-8\*p\*q+4\*q^2)


Penjelasan:


Akan dibuktikan bahwa




merupakan faktor dari




yaitu dengan mengalikannya kembali


\>$& expand(4\*p^2-8\*p\*q+4\*q^2)

\>$ powerdisp:true; //supaya tampilannya tetap 4p^2-8pq+4q^2, bukan 4q^2-8pq+4p^2


Karena hasil dari perkalian faktor tersebut menghasilkan hasil yang
sama, maka hasil pemfaktoran tersebut terbukti benar.


---



SOAL R.4 No 73


\>$& factor(3\*a^5-24\*a^2)


Penjelasan:


Akan dibuktikan bahwa




merupakan faktor dari




yaitu dengan mengalikannya kembali


\>$& expand(3\*(a-2)\*a^2\*(a^2+2\*a+4))

\>$ powerdisp:false; //supaya tampilannya tidak -12a^2+6a^3+3a^4+3a^5


Karena hasil dari perkalian faktor tersebut menghasilkan hasil yang
sama, maka hasil pemfaktoran tersebut terbukti benar.


---



Soal lain


\>$& factor(m^6+8\*m^3-20)  


---

---

# Operasi dan Fungsi Matematika

Fungsi adalah suatu relasi yang menghubungkan setiap anggota x dalam
suatu himpunan yang disebut daerah asal (domain) dengan suatu nilai
tunggal f(x) dari suatu himpunan kedua yang disebut daerah kawan
(kodomain).


Fungsi merupakan program dalam EMT yang didefinisikan dengan perintah


"function". Fungsi dapat berupa fungsi satu baris atau fungsi


multibaris.


Dalam satu baris, fungsi dapat berupa numerik atau simbolik. Fungsi
satu baris numerik didefinisikan oleh ":=".


\>function f(x):= 2x + 5


Fungsi di atas merupakan gambaran dari fungsi satu baris. % Suatu
fungsi dapat dievaluasi sama seperti fungsi Euler bawaan lainnya.


\>f(7)


    19

\>%+f(1)


    26

\>f(10)-f(3)


    14

\>f(3)\*f(2)


    99

\>f(8)/f(4)


    1.61538461538

\>f(2)+f(5)-f(6)


    7

\>f(1)^2


    49

\>sqrt(f(10))


    5

Fungsi juga dapat digunakan untuk vektor. Kami mengikuti bahasa
matriks Euler, karena ekspresi yang digunakan dalam fungsi tersebut
dapat divektorkan.


\>f(0:0.2:2)


    [5,  5.4,  5.8,  6.2,  6.6,  7,  7.4,  7.8,  8.2,  8.6,  9]

(0:0.2:2) adalah sintaks yang digunakan untuk membuat vektor dengan
langkah 0.2 dari 0 hingga 2. Sintaks ini biasanya digunakan untuk
membuat sebuah deret angka.


# Parameter Bawaan

Fungsi numerik dapat memiliki parameter default. Parameter default
adalah nilai atau konfigurasi yang telah ditentukan sebelumnya untuk
suatu fungsi. Parameter default digunakan ketika pemanggil fungsi dan
tidak menyediakan nilai untuk parameter tertentu.


\>function g(x,a=1) := a\*x^2+1

\>g(4)


    17

\>g(3)+g(2)


    15

\>g(6)/g(1)


    18.5

\>g(2)\*g(5)


    130

Jika suatu variabel bukanlah parameter, maka harus bersifat global.
Fungsi satu baris dapat melihat variabel global.


\>function h(x) := a\*x^2

\>a=2; h(3)


    18

Fungsi simbolik yang didefinisikan dengan "&amp;=". Maka fungsi tersebut
didefinisikan di Euler dan Maxima, dan bekerja di keduanya. Ekspresi
yang menentukan dijalankan melalui Maxima sebelum definisi.


\>function k(x) &= x^2-x\*exp(-x); $& k(x)

\>$&diff(k(x),x), $&% with x=3


Mereka juga dapat digunakan dalam ekspresi numerik. Tentu saja, ini
hanya akan berfungsi jika EMT dapat menafsirkan semua yang ada di
dalam fungsi tersebut.


Beberapa fungsi-fungsi yang digunakan dalam EMT:


&amp;= mendefinisikan fungsi simbolik,


:= mendefinisikan fungsi numerik,


&amp;&amp;= mendefinisikan fungsi simbolik murni.


\>k(5+k(1))


    31.7006135141

\>function P(x,n) &= (2\*x-1)^n; $&P(x,n)

\>function Q(x,n) &= (x+2)^n; $&Q(x,n)

\>$&P(x,4), $&expand(%)

\>P(3,4)


    625

\>$&P(x,4)+ Q(x,3), $&expand(%)

\>$&P(x,4)-Q(x,3), $&expand(%), $&factor(%)

\>$&P(x,4)\*Q(x,3), $&expand(%), $&factor(%)

\>$&P(x,4)/Q(x,1), $&expand(%), $&factor(%)

\>function r(x) &= x^3-x; $&r(x)

\>$&integrate(r(x),x)

\> 


# 1. Fungsi Trigonometri

Fungsi sinus, cosinus, dan tangen adalah klasifikasi utama fungsi
trigonometri. Adapun ketiga fungsi trigonometri lainnya yaitu
cotangen, secan, dan cosecan dapat diturunkan dari ketiga fungsi
tersebut.


* 
Sinus (lambang: sin) dalam matematika adalah perbandingan sisi
* segitiga yang ada di depan sudut dengan sisi miring.

* 
Kosinus atau cosinus (simbol: cos) dalam matematika adalah
* perbandingan sisi segitiga yang terletak di sudut dengan sisi miring.

* 
Tangen (lambang: tan) dalam matematika adalah perbandingan sisi
* segitiga yang ada di depan sudut dengan sisi segitiga yang terletak di
* sudut.
* (dengan catatan bahwa segitiga itu adalah segitiga siku-siku atau
* salah satu sudut segitiga itu 90 derajat).


Adapun untuk ketiga fungsi lainnya yaitu :


- cotangen(cot):


* 
secan(sec):
*   \frac{1}{cos(x)}

* 
cosecan (cosec/csc):
*   \frac{1}{sin(x)}


## Perhitungan menggunakan EMT



Dengan menggunakan EMT, kita dapat mencari nilai dari fungsi
sin,cos,tan,dll dengan lebih cepat.


\>x := 60°;


Perintah di atas mendefinisikan nilai x adalah 60 derajat. Adapun
fungsi dari titik koma dibelakang adalah agar hasilnya tidak terlihat.


\>sin(x)


    0.866025403784

Seperti yang dijelaskan sebelumnya bahwa x telah didefinisikan 60
derajat. Jadi, hanya dengan memanggil x maka program dengan otomatis
akan memunculkan nilai dari sin(60°)


\>&sin(60°)


    
                                   sqrt(3)
                                   -------
                                      2
    

Penulisan sintax di atas berbeda dengan yang sebelumnya. Tetapi untuk
hasil keduanya adalah equivalent.Untuk melakukan perhitungan
matematika simbolis di EMT, awali perintah maxima dengan tanda "&amp;".
Setiap ekspresi yang dimulai dengan "&amp;" adalah ekspresi simbolis dan
dikerjakan oleh Maxima.


\>$&sin(60°)


Penulisan sintax yang ini juga berbeda dengan dua penulisan di atas.
Sintaks di atas menampilkan hasil perhitungan simbolik secara lebih
bagus menggunakan LaTeX. Perbedaannya adalah adanya tanda "$" di awal
perintah di depan tanda &amp; pada perintah Maxima.


Selain fungsi sin, terdapat fungsi lain yang dapat dicari menggunakan
EMT. Diantaranya adalah:


\>$&cos(60°)

\>$&tan(60°)

\>$&cot(60°)

\>$&sec(60°)

\>$&csc(60°)


# 2. Fungsi Eksponensial

Fungsi eksponensial adalah fungsi yang memiliki bentuk


dengan a &gt; 0 dan a tidak sama dengan 0.


## Eksponen pangkat positif



Bentuk fungsi :


   dengan x adalah bilangan bulat positif.  



jadi jika


   a dikatakan sebagai basis dan 4 sebagai indeks.  

\>//gunakan simbol (^) untuk operasi pangkat


\>//contoh:


Cari nilai dari :


Jawaban:


\>$&(-3)^3


Penjelasan:


Menggunakan EMT, hasil dari nilai tersebut langsung menampilkan hasil
akhir. Adapun untuk langkah-langkah manualnya adalah sebagai beriku:


## Eksponen pangkat Negatif

Bentuk fungsi :


$$a^{-x} = \frac{1}{a^x}$$
   dengan a tidak sama dengan 0  

\>//contoh


Carilah nilai dari


jawaban:


\>$&2^-5


Penjelasan:


Menggunakan EMT, hasil dari nilai tersebut langsung menampilkan hasil
akhir. Adapun untuk langkah-langkah manualnya adalah sebagai berikut:


## Eksponen pangkat nol



Bentuk:




dengan a tidak sama dengan 0


\>//contoh


carilah nilai dari


Jawaban:


\>$& 37^0

\>$& (-3/7)^0


Penjelasan:


Menggunakan EMT, hasil dari nilai tersebut langsung menampilkan hasil
akhir.


## Sifat-sifat Eksponen



Jika p dan q adalah bilangan real, maka berlaku sifat-sifat berikut:


A. Sifat 1


\>//contoh a.1


Carilah nilai dari


jawaban


\>& c^3 \* c^5


    
                                       8
                                      c
    

Penjelasan:


Menggunakan EMT, hasil dari nilai tersebut langsung menampilkan hasil
akhir. Adapun untuk langkah-langkah manualnya adalah sebagai berikut:


\>//contoh a.2


Carilah nilai dari


Jawaban:


\>& 3^8 \* 3^-2


    
                                     729
    

Penjelasan:


Menggunakan EMT, hasil dari nilai tersebut langsung menampilkan hasil
akhir. Adapun untuk langkah-langkah manualnya adalah sebagai berikut:


\>//latihan soal


Carilah nilai dari


\>& (x+2)^4 \* (x+2)^-2


    
                                          2
                                   (x + 2)
    

Penjelasan:


Menggunakan EMT, hasil dari nilai tersebut langsung menampilkan hasil
akhir. Adapun untuk langkah-langkah manualnya adalah sebagai berikut:


---

B. Sifat 2


\>//contoh


carilah nilai dari


jawab:


\>$&(x^2)^5


Penjelasan:


Menggunakan EMT, hasil dari nilai tersebut akan langsung menampilkan
hasil akhir. Adapun untuk langkah-langkah manualnya adalah sebagai
berikut:


\>//latihan soal


carilah nilai dari:


jawab:


\>$&(5^2)^3


Penjelasan:


Menggunakan EMT, hasil dari nilai tersebut langsung menampilkan hasil
akhir. Adapun untuk langkah-langkah manualnya adalah sebagai berikut:


---



C. Sifat 3


Dengan a tidak sama dengan 0, berlaku:


\>//latihan soal


carilah nilai dari


\>$& (x^2\*y^-2)/(x^-1\*y)


Penjelasan:


Menggunakan EMT, hasil dari nilai tersebut langsung menampilkan hasil
akhir. Adapun untuk langkah-langkah manualnya adalah sebagai berikut:


---



D. Sifat 4


\>//latihan soal


carilah nilai dari


Jawaban:


\>$&(2\*x\*2\*y)^3


Penjelasan:


Menggunakan EMT, hasil dari nilai tersebut langsung menampilkan hasil
akhir. Adapun untuk langkah-langkah manualnya adalah sebagai berikut:


\> 


---



E. Sifat 5


Dengan b tidak sama dengan 0, berlaku:


\>//latihan soal


Carilah nilai dari


\>$& ((a^2\*b^-3\*c^5)/(a^2\*b^-2\*c^3))^-2


Penjelasan:


Menggunakan EMT, hasil dari nilai tersebut langsung menampilkan hasil
akhir. Adapun untuk langkah-langkah manualnya adalah sebagai berikut:


# 3. Fungsi Logaritma

Logaritma merupakan kebalikan (invers) dari pemangkatan.


Suatu bentuk pemangkatan dapat diubah menjadi bentuk logaritma


dan sebaliknya.


Bentuk Umum:


Untuk 0&lt;a&lt;1 atau a&gt;1, dan b&gt;0 berlaku:


keterangan :


a disebut bilangan pokok (basis)


b disebut numerus


\>//cara menggunakan logaritma umum di emt dengan basis a : logbase(b,a)

\>//cara menggunakan logaritma umum di emt dengan basis 10 : log10(b)

\>3^4


    81

Contoh di atas adalah salah satu bentuk contoh eksponen.


\>logbase(81,3)


    4

Cara untuk mencari nilai dari logaritma umum dengan menggunakan EMT
adalah dengan menuliskan sintax 'logbase(numerus,basis)'.


Dan sesuai dengan bentuk contoh eksponen di atas, maka persamaan
dengan bentuk logaritmanya adalah


## Sifat-sifat logaritma

Untuk a, b, c bilangan real positif


1. Untuk a tidak sana dengan 0, berlaku


$$^alog bc = ^a log b + ^a log c$$
\>//contoh


Apakah


jawab:


\>logbase(4,2)+ logbase(8,2)


    5

\>logbase(8\*4, 2)


    5

Apabila mengetahui sintax yang akan digunakan. Seperti yang telah
dijelaskan sebelumnya, sintax dari mencari nilai logaritma basis
selain 0 adalah 'logbase(numerus,basis)'dan gunakan operasi-operasi
yang dibutuhkan seperti perkalian(*) dan penjumlahan(+).


Hal yang perlu dilakukan hanyalah mencari tahu nilai dari kedua ruas
apakah memiliki nilai yang sama.


---



2. Untuk a&gt;0, a tidak sama dengan 1, dan b&gt;0, berlaku


$$^alog (\frac{b}{c}) = ^alogb - ^alogc$$
\>//contoh


Apakah


$$^3log27 - ^3log3 = ^3log(\frac{27}{3}) ?$$
\>logbase(27,3)-logbase(3,3)


    2

\>logbase(27/3,3)


    2

Apabila mengetahui sintax yang akan digunakan. Seperti yang telah
dijelaskan sebelumnya, sintax dari mencari nilai logaritma basis
selain 0 adalah 'logbase(numerus,basis)'dan gunakan operasi-operasi
yang dibutuhkan seperti pembagian(/) dan pengurangan(-).


Hal yang perlu dilakukan hanyalah mencari tahu nilai dari kedua ruas
apakah memiliki nilai yang sama.


---



3. Untuk n bilangan asli serta a&gt;0, a tidak sama dengan 1, dan b&gt;0,
berlaku:


$$^alogb^n = n^alogb$$
\>//contoh


Tunjukkan bahwa pernyataan di bawah benar menggunakan EMT!


$$^2log4^2 = 2 ^2log4 ?$$
\>logbase(4^2,2)


    4

\>logbase(4,2)\*2


    4

Terbukti bahwa


$$^2log4^2 = 2 ^2log4$$


Benar


---



4. Untuk a,b,c tidak sama dengan 1


\>//contoh


Apakah


jawab:


\>logbase(7,3)


    1.77124374916

\>logbase(7,7)/logbase(3,7)


    1.77124374916

\>1/logbase(3,7)


    1.77124374916

Terbukti bahwa




Benar


---



5. Untuk a,b,c tidak sama dengan 1, berlaku:


\>//contoh


Apakah


Tunjukkan bahwa pernyataan di atas benar!


\>logbase(3,2)\*logbase(32,3)


    5

\>logbase(32,2)


    5

Terbukti bahwa




Benar


---



6. untuk a tidak sama dengan 1, berlaku:


\>//contoh


Tunjukkan bahwa pernyataan berikut benar




jawab:


\>2^logbase(4,2)


    4

Terbukti bahwa




Benar


## 4. Fungsi Linear



Fungsi linear adalah suatu fungsi yang membentuk grafik secara garis
lurus. Fungsi linear ini juga menjadi fungsi yang telah mendapatkan
pangkat tertinggi dengan variabelnya sama dengan satu.


Bentuk umum dari fungsi linear


f(x)= ax + b atau y = ax + b


f(x)merupakan fungsi yang didefinisikan


a merupakan koefisien dari x


b merupakan konstanta


Misal ada fungsi


kemudian akan dicari nilai dari y dengan nilai x diketahui sebagai 3


lalu subtitusi x = 3 ke persamaan y = x+9


\>//contoh

\>function f(x):= 2x + 5

\>f(10)


    25

## 5. Fungsi Pangkat



Fungsi Pangkat merupakan fungsi dengan variabel bebasnya berpangkat
suatu bilangan riil dalam persamaannya.


Bentuk umum dari fungsi pangkat


f(x) = fungsi pangkat


x = variabel


a = koefisien x^n, n tidak boleh sama dengan 0.


b = koefisien x


c = konstanta


\>//contoh


\>function f(x,y):= x^2+5y

\>f(4,10)


    66

\>function m(x):= x^2+5x+6

\>m(3)


    30

\>function m(x)&= x^2+5\*x+6


    
                                  2
                                 x  + 5 x + 6
    

\>& m(a)


    
                                  2
                                 a  + 5 a + 6
    

## 6. Fungsi Polinomial



Fungsi polinomial adalah fungsi yang hanya melibatkan pangkat bilangan
bulat non negatif atau hanya eksponen bilangan bulat positif dari
suatu variabel dalam persamaan seperti persamaan kuadrat dan
lain-lain.


(Polinomial)Suku banyak adalah suatu bentuk matematika yang merupakan
penjumlahan atau pengurangan dari satu suku atau lebih dengan pangkat
variabelnya harus bilangan bulat dan tidak negatif.


Bentuk umum fungsi polinomial


\>//contoh


\>$& factor(3\*x^3-4\*x^2+2\*x+4)


Sederhanakan pembilang dan penyebut dengan dibagi 3x+2


\>$& factor(3\*x^3-4\*x^2+2\*x+4)/(3\*x+2)


## 7. Fungsi Rasional



Fungsi rasional adalah fungsi matematika yang didefinisikan sebagai
rasio (pembagian) antara dua polinomial.


Bentuk umum fungsi rasional


dengan q(x) tidak sama dengan 0


\>//contoh


\>$& factor(16\*x^4-1)


Sederhanakan pembilang dan penyebut dengan dibagi 2x-1


\>$& factor(16\*x^4-1)/(2\*x-1)


## 8. Fungsi Komposisi



Fungsi komposisi adalah fungsi yang melibatkan lebih dari satu fungsi.
Ketika ada suatu fungsi, kemudian dilanjutkan dengan fungsi lainnya,
maka akan membentuk suatu fungsi baru. Fungsi baru inilah fungsi hasil
komposisi dari kedua fungsi sebelumnya.


Contoh Fungsi Komposisi


1.


(f o g)(x) dapat dibaca “fungsi f komposisi g” atau “f bundaran g”,
yang artinya fungsi yang dipetakan oleh fungsi g(x) kemudian
dilanjutkan oleh fungsi f(x). Jadi, fungsi g nya dikerjakan terlebih
dahulu, kemudian hasilnya dimasukkan ke dalam fungsi f.


2.


(g o f)(x) dapat dibaca “fungsi g komposisi f” atau “g bundaran f”,
yang artinya fungsi yang dipetakan oleh fungsi f(x) kemudian
dilanjutkan oleh fungsi g(x). Kalau g o f, yang dikerjakan terlebih
dahulu adalah fungsi f, kemudian dilanjutkan atau dimasukkan dalam
fungsi g.


image: Sifat-Sifat Fungsi Komposisi.png


\>//contoh

\>function f(x):= 2x + 5

\>function g(x):= x^2+1

\>f(g(1))


    9

\>g(f(1))


    50

## 9. Fungsi Invers



Fungsi invers atau fungsi kebalikan merupakan suatu fungsi yang
berkebalikan dari fungsi asalnya. Suatu fungsi f memiliki fungsi
invers (kebalikan) f^-1 jika f merupakan fungsi satu-satu dan fungsi
pada (bijektif). Hubungan tersebut dapat dinyatakan sebagai berikut:


Ada 3 langkah untuk menentukan fungsi invers, yaitu:


1. Ubahlah bentuk y = f(x) menjadi bentuk x = f(y).


2. Tuliskan x sebagai f^-1(y) sehingga f^-1(y) = f(y).


3. Ubahlah variabel y dengan x sehingga diperoleh rumus fungsi invers
f^-1(x).


image: table rumus invers.png


\>//contoh

\>function f(x):= 2x + 5

\>inv(f(6))


    0.0588235294118

---

---

# Bilangan Kompleks

## Penjelasan mengenai Bilangan Kompleks

EMT dapat menggunakan bilangan kompleks. Tersedia banyak fungsi untuk
bilangan kompleks di EMT.


Bilangan kompleks dimasukkan dengan menambahkan i ke bagian imajiner.
Bilangan imaginer


i = v -1


dituliskan dengan huruf I (huruf besar I), namun akan ditampilkan
dengan huruf i (i kecil).


\>sqrt(-1)


    Floating point error!
    Error in sqrt
    Error in:
    sqrt(-1) ...
            ^

sqrt(-1) tidak akan berfungsi. Jadi akar kuadrat -1 akan menghasilkan
kesalahan.


Untuk mengubah bilangan real x menjadi bilangan kompleks, gunakan
complex(x).


\>sqrt(complex(-1))


    0+1i

re(x) : bagian riil pada bilangan kompleks x.


m(x) : bagian imaginer pada bilangan kompleks x.


omplex(x) : mengubah bilangan riil x menjadi bilangan kompleks.


onj(x) : Konjugat untuk bilangan bilangan komplkes x.


rg(x) : argumen (sudut dalam radian) bilangan kompleks x.


eal(x) : mengubah x menjadi bilangan riil.


re(z) dan im(z) hanya menghitung bagian real dan imajiner dari sebuah
bilangan kompleks.


## Melakukan Perhitungan menggunakan Bilangan Kompleks

\>$& sqrt(-1)


Soal pertama (Ubah bentuk dengan aturan i)


\>$& ((-4)-sqrt(-4))/(2)

\>$& ((-2\*i)/2)-((4)/(2))


Jadi untuk penyelesaian di atas pertama-tama mengubah akar -4 menjadi
aturan i


dengan mengubah bentuk akar negatif 4 menjadi


Dengan begitu bentuk tersebut kita bisa ubah menjadi


Sehingga akar 4 kita bisa ubah bentuk menjadi 2 dan akar negatif 1
sesuai dengan aturan i yaitu


Sehingga bentuknya dapat kita ubah menjadi


dilanjutkan dengan pembagian biasa dan hasilnya menjadi


\>(1+sqrt(complex(-1)))^3


    -2+2i

Soal Kedua


\>$& -2+2\*i // jawaban menggunakan latex


Untuk soal nomor 2 dapat dijabarkan menjadi


Karena aturan i yang dimana


sehingga ketika i pangkat 2 dapat diubah menjadi -1 karena


Selanjutnya ketika i pangkat tiga diubah menjadi -1i karena


Sehingga penjabaran dari soal nomor dua dapat diubah menjadi


Sehingga ketika dilakukan operasi penjumlahan dan pengurangan
jawabannya menjadi


Soal ketiga


\>$& (sqrt(-1)+((sqrt(-1))^2)+(sqrt(-1)^3)+((sqrt(-1)^4)))/(1+sqrt(-1))


Pada soal ketiga hasil dari penyederhanaan dari soal ketiga adalah


Sehingga ketika dilanjutkan dengan operasi perkalian menjadi


Selanjutnya untuk i pangkat 3 dapat diubah menjadi -1i karena


Kemudian dapat dari operasi tersebut menghasilkan


Dengan operasi penjumlahan, hasil dari permasalahan tersebut adalah


---

---

# Fungsi-Fungsi Buatan Sendiri 

## 1. Fungsi Inti 



Banyak fungsi matematika dasar (operator, fungsi trigonometri, fungsi
eksponensial, dll) tercantum dalam fungsi inti.


## 2. Fungsi Hiperbolik

\>sinh(60°)


    1.24936705052

\>cosh(60°)


    1.6002868577

\>asinh(30)


    4.09462222433

\>acosh(30)


    4.09406666863

\> sec(60°)


    2

\>cosec(60°)


    1.15470053838

\>cot(60°)


    0.57735026919

## 3. Koordinat kutub

\>polar(1, 2)


    1.10714871779

\>polar(3,7,4)


    1.16590454051

\>rect(45, sqrt(2))


    0.742917481199

## 4. Polinomial

\>polydif([0,1,1])


    [1,  2]

---

---

# Menyelesaikan Persamaan dan Sistem Persamaan

Persamaan adalah suatu pernyataan matematika dalam bentuk simbol yang
menyatakan bahwa dua hal adalah persis sama. Persamaan ditulis dengan
tanda sama dengan (=), seperti berikut:


\> $& solve(x+3=5)

\> $& solve(2\*x-8=10)


## Persamaan Linier

Persamaan linear adalah sebuah persamaan aljabar, yang tiap sukunya
mengandung konstanta, atau perkalian konstanta dengan variabel
tunggal. Persamaan ini dikatakan linear sebab hubungan matematis ini
dapat digambarkan sebagai garis lurus dalam Sistem koordinat
Kartesius.


*** Persamaan Linier Satu Variabel


Bentuk umum Persamaan Linear Satu Variabel adalah


Contoh sistem persamaan linier dua variabel


Selesaikan dari persamaan diatas


\> $& solve(10\*x+2=22)


---



*** Persamaan Linier Dua Variabel


Bentuk umum Persamaan Linear Dua Variabel adalah


Contoh sistem persamaan linier dua variabel


Selesaikan sistem persamaan di atas


\> $& solve([x+2\*y=10,5\*x-3\*y+6=-9\*x+8\*y+4])

\> $& solve([5\*x-3\*y+6=0 , -9\*x+8\*y+4=0])


---



*** Persamaan Linier Tiga Variabel


Bentuk umum Persamaan Linear Satu Variabel adalah


Contoh sistem persamaan linier tiga variabel


Jika diketahui sistem persamaan


a - 6b = -1 + 5c


a + c = b - 3a,


6 = 3c + b - 3a,


maka hasil kali semua x yang memenuhi persamaan


(x-4)(x^2-a^2)=(x+b)(x+c) adalah...


Selesaikan sistem persamaan di atas


\> sol &= solve([7\*a-6\*b=-1+5\*c,2\*a+c=b-3\*a,-6=3\*c+b-3\*a],[a,b,c])


    
                          [[a = 1, b = 3, c = - 2]]
    

Jabarkan bentuk polinomialnya


\> $& showev('expand((x-4)\*(x^2-a^2)=(x+b)\*(x+c)))


Subtitusi nilai a,b, dan c akan diperoleh


\> $& showev('expand((x-4)\*(x^2-a^2)=(x+b)\*(x+c))) with a=1 with b=3 with c=-2 


Kumpulkan di ruas kiri suku-suku yang sejenis


\> $& (x^3-4\*x^2-x+4=x^2+x-6)

\> $&(x^3-5\*x^2-2\*x+10=0) 


merupakan polinomial berderajat 3 sehingga memiliki 3 akar-akar
penyelesaian. Ditanyakan soal adalah hasil kali semua x yang memenuhi
persamaan.


Jika di ketahui persamaan




Hasil kali semua x yang memenuhi persamaan adalah




Persamaan




a=1, b=-5, c=-2, d=10


Sehingga, hasil kali semua x yang memenuhi persamaan




adalah


## Persamaan Logaritma

Persamaan logaritma adalah suatu persamaan matematis yang memuat
variabel x di dalam fungsi logaritmanya (numerus).


Bentuk umum Logaritma




Dengan:


a = bilangan pokok atau basis


b = numerus


n = nilai logaritma


Pada persamaan logaritma, numerus memuat suatu variabel, misalnya x
atau y


Bentuk umum Persamaan Logaritma




Dengan:


a = basis (bilangan pokok)


f(x) dan g(x) = numerus dalam bentuk fungsi


Agar suatu persamaan logaritma bisa terdefinisi, nilai numerus harus
lebih besar dari nol. Artinya, solusi persamaan harus mengacu pada
syarat tersebut.


Persamaan Logaritma Bentuk 1


image: Logaritma1.png


Contoh soal 1


Tentukan nilai x yang memenuhi persamaan




Penyelesaian :


---



Persamaan Logaritma Bentuk 2


image: Logaritma2.png


\>  


## Persamaan Kuadrat



Persamaan kuadrat disebut juga persamaan suku banyak atau polinomial.
Persamaan kuadrat adalah sebuah persamaan dengan pangkat tinggi
maksimal dua atau berorde dua.


Bentuk umum Persamaan Kuadrat adalah


Contoh soal 1


tentukan faktor dari


\>$& solve((m^2+(m-2)\*m+2\*m-4=0))


Contoh soal 2


tentukan soal dari


\>$& solve(5\*x^2+7\*x+10=0)


## Persamaan Trigonometri

Persamaan trigonometri adalah persamaan matematika yang memuat fungsi
trigonometri dari sudut yang belum diketahui nilainya. Persamaan ini
mirip persamaan linear atau kuadrat. Yang membedakan antara
trigonometri dengan yang lainnya adalah himpunan penyelesaiannya
berupa besaran sudut.


\> $& solve (sin(x)=1)

\> $& solve(cos(x)=1)

\> $& solve(2\*cos(2\*x-60°)- sqrt(3)=0)

\> $& solve(tan(x-45°)=cot(90°))

\> $& solve([sin(x+pi/4) = 0], [x])


## Persamaan Eksponensial

Persamaan eksponen adalah persamaan bilangan berpangkat yang memuat
variabel di bagian pangkatnya. Oleh karena memuat suatu variabel, maka
pangkatnya bisa dinyatakan sebagai suatu fungsi, misal f(x) atau g(x)
untuk pangkat bervariabel x


Bentuk umum persamaan eksponen adalah




dengan


a = basis(bilangan pokok)


f(x) dan g(x) = pangkat atau eksponen


Contoh persamaan eksponen


Sifat-sifat Persamaan Eksponen


image: sifat.png


Contoh soal persamaan eksponen


Soal 1




Penyelesaian :


Identifikasi dahulu kedua basisnya. Jika basisnya sama, maka nilai
pangkat basis pertama akan sama dengan pangkat basis kedua


\> $& solve(x+1=4)


---



Soal 2




Penyelesaian :


Identifikasi dahulu kedua basisnya. Jika basisnya sama, maka berlaku
sifat kedua


\> $& solve(5\*x-2=x+2)


---



Soal 3




Penyelesaian :


Identifikasi dahulu kedua basisnya. Jika basisnya tidak sama, namun
bentuk eksponennya sama, maka berlaku sifat ketiga


\> $& solve(2\*x-6=0)


---



Soal 4


Tentukan himpunan dari


Penyelesaian:


Identifikasi dahulu kedua ruas. Akan berlaku sifat keempat


\> function h(x):=x-6

\> function f(x):=6\*x

\> function g(x):=5\*x+1


Solusi 1


\> $& solve((6\*x)=(5\*x+1))


(memenuhi solusi)


Solusi 2


\> $& solve(x-6=1)


(memenuhi solusi)


Solusi 3




dengan syarat f(x) dan g(x) keduanya genap/ganjil


\> $& solve(x-6=-1)


Untuk x=5, maka


\>f(5)


    30

\>g(5)


    26

Karena keduanya genap maka x=5 memenuhi


Solusi 4




dengan syarat f(x) dan g(x) keduanya positif


\> $& solve(x-6=0)


Untuk x=6, maka


\> f(6)


    36

\> g(6)


    31

---

---

# Pertidaksamaan dan Sistem Pertidaksamaan

# 1. Pertidaksamaan Linear (Pangkat Satu) a. Pertidaksamaan linear

satu variabel


Pertidaksamaan linear satu variabel merupakan bentuk pertidaksamaan
dengan memuat satu peubah (variabel) dengan pangkat tertingginya
adalah satu.


Bentuk umum


Contoh soal


Untuk menyelesaikan pertidaksamaan, EMT tidak akan dapat melakukannya,


melainkan dengan bantuan Maxima, artinya secara eksak (simbolik).
Perintah Maxima yang digunakan adalah fourier_elim(), yang harus
dipanggil dengan perintah "load(fourier_elim)" terlebih dahulu.


\>&load(fourier\_elim)


    
            C:/Program Files/Euler x64/maxima/share/maxima/5.35.1/share/f\
    ourier_elim/fourier_elim.lisp
    

\>$&fourier\_elim([x + 10 \> 0],[x])

\>$&fourier\_elim([2\*x \> 15],[x])

\>$&fourier\_elim([3\*x - 18 \> 0 ],[x])


---



b. Pertidaksamaan linear dua variabel


Pertidaksamaan linear dua variabel adalah bentuk pertidaksamaan yang
memuat dua peubah (variabel) dengan pangkat tertinggi variabel
tersebut adalah satu.


Bentuk umum


Contoh soal


\>$&fourier\_elim((x + y < 5) and (x - y \> 0),[x,y])

\>$&fourier\_elim((y - x < 5) and (x - y < 15) and (10 < y),[x,y]) // sistem pertidaksamaan

\>$&fourier\_elim((x + y < 9) and (x - y \> 7),[x,y])


# 2. Pertidaksamaan Kuadrat Pertidaksamaan kuadrat ialah

pertidaksamaan yang mempunyai variabel dimana pangkatnya memuat satu
atau lebih perubahan serta relasi “lebih dari”, “lebih dari atau sama
dengan”, “kurang dari”, atau “kurang dari sama dengan”.


Bentuk umum


---



Contoh soal


\>&load (fourier\_elim)


    
            C:/Program Files/Euler x64/maxima/share/maxima/5.35.1/share/f\
    ourier_elim/fourier_elim.lisp
    

\>$& fourier\_elim([x^2 + 9\*x + 20 \>= 0], [x])


\>$& fourier\_elim([x^2 + 8\*x + 15 \> 0], [x])


\>$& fourier\_elim([x^2 + 6\*x + 9 \> 0], [x])


# 3. Pertidaksamaan Logaritma Pertidaksamaan logaritma adalah

pertidaksamaan yang memuat fungsi logaritma di dalamnya.


Bentuk umum


Konsep pertidaksamaan logaritma


a) Untuk a &gt; 1, tanda ketaksamaannya tetap (tidak berubah)


b) Untuk a &lt; 1, tanda ketaksamaannya berubah (dibalik)


---



Contoh soal


\>$&fourier\_elim ([x + 1 \> 8], [x])


\>$&fourier\_elim ([2\*x - 3 \>= x + 1], [x])


karena a &lt; 1 maka tanda ketaksamaannya berubah sehingga


\>$&fourier\_elim ([5\*x + 3 < x - 2], [x])


# 4. Pertidaksamaan Trigonometri Pertidaksamaan trigonometri merupakan

pertidaksamaan yang mengandung fungsi-fungsi trigonometri, baik sinus,
cosinus, tangen, cotangen, secan dan cosecan.


Contoh soal


\>$& fourier\_elim([2\*sin(x)<=1],[x])

\>$& solve (2\*sin(x)-1=0)

\> 


\>$& fourier\_elim([2\*cos(2\*x)< 1],[x])


\>$& fourier\_elim([tan(x)\> 1],[x])


# 5. Pertidaksamaan Eksponen Eksponen merupakan bentuk penulisan

bilangan berpangkat atau perkalian secara berulang sebanyak
pangkatnya. Pertidaksamaan eksponen adalah bentuk pertidaksamaan pada
bilangan berpangkat yang memuat variabel, seperti x.


Bentuk pertidaksamaan eksponen:


Secara umum, bentuk pertidaksamaan eksponen dibagi menjadi dua, yaitu
sebagai berikut.


a) Jika bilangan pokok a &gt; 1, untuk




b) Jika bilangan pokok 0 &lt; a &lt; 1, untuk


---



Contoh soal


ubah bentuk eksponen menjadi basis 3 sehingga




karena basis sudah sama, selesaikan menggunakan bantuan emt


\>$&fourier\_elim ([3\*x-9 < 4\*x+20],[x])




ubah bentuk ekspnen menjadi basis 2 sehingga




karena basis sudah sama, selesaikan menggunakan bantuan emt


\>$&fourier\_elim ([2\*x+3 < 3\*x-15],[x])


\>$&fourier\_elim ([5\*x-7 < x+2],[x])


karena 0 &lt; a &lt; 1, maka tanda pertidaksamaan dibalik. sehingga


---

---

# Menggunakan aljabar 

* untuk menyelesaikan masalah sehari-hari


Soal 1


Seorang petani ingin menghitung total luas lahan pertanian yang akan
dia tanami dengan dua jenis tanaman berbeda: jagung dan kacang hijau.
Dia memiliki bidang persegi panjang dengan panjang 100 meter dan lebar
50 meter. Dia ingin menanam jagung di setengah bidang tersebut dan
kacang hijau di setengah sisanya. Luas tanah yang akan ditanami jagung
adalah berapa meter persegi?


\>panjang = 100;

\>lebar = 50;

\>$&LuasTotal = 100 \* 50


Luas tanah yang akan ditanami jagung (setengahnya)


\>$&LuasJagung = 5000/2


Luas tanah yang akan ditanami jagung adalah 2500 meter persegi.


Soal 2


Seorang investor ingin menghitung berapa jumlah uang yang akan dia
miliki setelah menanam sejumlah uang dalam rekening tabungan dengan
suku bunga tertentu selama beberapa tahun. Jika dia menanam Rp.
5,000,000 di rekening tabungan dengan suku bunga tahunan sebesar 5%,
berapa jumlah uang yang akan dia miliki setelah 3 tahun?


\>$& JumlahAkhir = 5000000\*(1+0.05)^3


Jumlah uang yang akan dimiliki investor setelah 3 tahun adalah Rp.
5,788,125


Soal 3


Harga 3 buah buku dan 5 pensil adalah Rp. 42.000,00. Jika harga sebuah
buku adalah 3 kali harga sebuah pensil.


Tentukanlah harga masing-masing pensil dan buku !


\>$&HargaPensil = 42000/14

\>$&HargaBuku = 3\*3000


Jadi,


Harga sebuah pensil adalah Rp 3.000,00


Harga sebuah buku adalah 3 x Rp 3.000,00 adalah Rp.9.000,00


Karena keduanya positif, maka x = 6 memenuhi.


Jadi, hasil dari himpunan adalah HP = {1, 5, 6, 7}


